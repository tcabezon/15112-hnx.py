import numpy as np
from stl import mesh
import math
from matplotlib import pyplot
from mpl_toolkits import mplot3d
from functions import *


#####################################################
# PARAMETERS
#####################################################
center=[0.,0.,0.]
stepU=10
stepV=10
r=100

bezierVertices=np.array([[608.0, 88.0], [673.7143728090227, 75.27853138918522], [720.4910836762689, 86.32528916662434], [748.3209876543212, 113.47325102880662], [757.9448254839201, 149.73008857050925], [750.8898033836306, 189.31670307710544], [729.5061728395062, 228.2057613168724], [697.003810394757, 264.66023133329946], [657.4887974394146, 299.771918237396], [608.0, 338.0]])
minY=np.min(bezierVertices[:,1])
print(minY)
bezierVertices-=75.27853138918522
print(bezierVertices)
# generate the mesh
sphere= sphereMesh(center,stepU,stepV,r)


# SAVE THE MODEL
sphere.save('sphere.stl')


# PLOTTING
# Create a new plot
figure = pyplot.figure()
axes = mplot3d.Axes3D(figure)

# Add the vectors to the plot
#using matplot library to plot the 3D mesh
axes.add_collection3d(mplot3d.art3d.Poly3DCollection(sphere.vectors, facecolors='b',edgecolors='k', linewidths=1, alpha=0.75))


# Auto scale to the mesh size
scale = sphere.points.flatten()
axes.auto_scale_xyz(scale, scale, scale)
#axes.scatter3D(vertices[:,0], vertices[:,1], vertices[:,2])

# Show the plot to the screen
pyplot.show()



vertices=np.array([[608.0, 88.0], [673.7143728090227, 75.27853138918522], [720.4910836762689, 86.32528916662434], [748.3209876543212, 113.47325102880662], [757.9448254839201, 149.73008857050925], [750.8898033836306, 189.31670307710544], [729.5061728395062, 228.2057613168724], [697.003810394757, 264.66023133329946], [657.4887974394146, 299.771918237396], [608.0, 338.0]])
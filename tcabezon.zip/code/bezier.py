from cmu_112_graphics import *
import numpy as np
from stl import mesh
import math

from stl import mesh
from mpl_toolkits import mplot3d
from matplotlib import pyplot
from functions import *


def bezier_appStarted(app):
    app.label = 'animation'
    #points
    app.pointList=[]
    app.r = 2
    app.numberOfBezierPoints=10


def bezier_mousePressed(app, event):
    newPoint =  [event.x, event.y]
    app.pointList.append(newPoint)
    
    

def bezier_redrawAll(app, canvas):
    drawPoints(canvas,app.pointList)
    drawBezierCurve(canvas,app)


def bezier_keyPressed(app, event):
    pass
        


runApp(width=1400, height=1400, fnPrefix='bezier_')